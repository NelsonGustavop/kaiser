![IMAGEM ILUSTRATIVA](https://user-images.githubusercontent.com/87662269/193574678-a27a1e37-6e60-4016-b83f-7ee7777216ef.PNG)

<h1 align="center">
 PORTFOLIO 📋
</h1>

<h2>
  :pencil: Descrição do projeto
</h2>

<p>
Esse projeto trata-se do meu portfolio pessoal, onde mostro alguns dos meus projetos, skills e certificados.
</p>

## 🛠️ Feito com
* [Visual Studio Code](https://code.visualstudio.com) - Coding Editor

## 💻 Tecnologias utilizadas
<div display="flex">
  <img align="center" alt="leo-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
 <img align="center" alt="leo-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
 <img align="center" alt="leo-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
</div>

## :link: Deploy

```
https://leonardojpereira.github.io/portfolio/
```

## Imagem / Icones

https://fontawesome.com/

⌨️ with ❤️ by [Leonardo Barbosa](https://github.com/leonardojpereira) 😊

<h3 align="center">
  
  :construction: PROJETO FINALIZADO :construction:
  
</h3>
